App({
  onLaunch: function () {
    //云开发函数的初始化
    wx.cloud.init(
      {
        env:"waimai-0g1zosr35d4233d7"
      }
    )
}
})
