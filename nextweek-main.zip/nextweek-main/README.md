# NextWeek 下周很重要
[https://github.com/mxyblog/nextweek](https://github.com/mxyblog/nextweek)

计划不写下来，不告诉自己必须完成，它根本不会出现

### 灵感来源

    连叔的下周很重要

### 已上线案例

![下周计划](https://note.youdao.com/yws/api/personal/file/10B7861B38B34C77AA0D3F2F095D1254?method=download&shareKey=dd8dd2536354495007401619666fce73)

### 致谢
- https://github.com/zce/weapp-todos